Breakout Board for USB microB
=============================


[![USB microB Breakout](https://dlnmh9ip6v2uc.cloudfront.net/images/products/9/6/1/4/09614-01b_i_ma.jpg)  
*USB microB Breakout (BOB-09614)*](https://www.sparkfun.com/products/9614)

This breakout board gives access to a micro-B USB connector's VCC, GND, D-, and D+ pins. 

Repository Contents
-------------------
* **/Hardware** - All Eagle design files (.brd, .sch)

License Information
-------------------
The hardware is released under Creative Commons Share-alike 3.0.
